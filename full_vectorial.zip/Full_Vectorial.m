clear; clc; close all;

%%  PARAMETERS
lambda0 = 800e-9;
k0 = 2*pi/lambda0;

n_core = 1.4833;
n_clad = 1.4533;

a = 10e-6;      % core radius
R = 25e-6;     

%% MESH GENERATION
N_angular = 72;

r_vals = [linspace(0,a,40), linspace(a+1e-9,R,20)];
theta_vals = linspace(0,2*pi,N_angular+1);
theta_vals(end)=[];

nodes=[];
for r=r_vals
    nodes=[nodes; r*cos(theta_vals'), r*sin(theta_vals')];
end

nodes = unique(round(nodes,14),'rows');
tri = delaunay(nodes(:,1),nodes(:,2));
numElems = size(tri,1);

%% EDGE MAPPING (Nedelec DOF)
edgeMap = containers.Map('KeyType','char','ValueType','double');
edges=[];
elems2edges=zeros(numElems,3);
edgeSigns=zeros(numElems,3);

for k=1:numElems
    en=tri(k,:);
    for e=1:3
        n1=en(e);
        n2=en(mod(e,3)+1);
        key=sprintf('%d_%d',min(n1,n2),max(n1,n2));
        if ~isKey(edgeMap,key)
            edges=[edges; min(n1,n2) max(n1,n2)];
            edgeMap(key)=size(edges,1);
        end
        elems2edges(k,e)=edgeMap(key);
        edgeSigns(k,e)=sign(n2-n1);
    end
end

numEdges=size(edges,1);

%% MATERIAL 
eps_elem = n_clad^2*ones(numElems,1);

for k=1:numElems
    center = mean(nodes(tri(k,:),:));
    if norm(center)<=a
        eps_elem(k)=n_core^2;
    end
end

%% MATRIX ASSEMBLY 
K = sparse(numEdges,numEdges);        % curl-curl
M = sparse(numEdges,numEdges);        % mass
M_eps = sparse(numEdges,numEdges);    % epsilon mass

quad_pts = [1/6 1/6; 2/3 1/6; 1/6 2/3];
quad_w = [1/6 1/6 1/6];

for k=1:numElems

    vid = tri(k,:);
    v = nodes(vid,:);

    BK = [v(2,:)-v(1,:); v(3,:)-v(1,:)]';
    detBK = det(BK);
    area = abs(detBK)/2;

    eps_k = eps_elem(k);

    % Gradients of barycentric coordinates
    grad_lambda = zeros(2,3);
    grad_lambda(:,1) = [v(2,2)-v(3,2); v(3,1)-v(2,1)]/detBK;
    grad_lambda(:,2) = [v(3,2)-v(1,2); v(1,1)-v(3,1)]/detBK;
    grad_lambda(:,3) = [v(1,2)-v(2,2); v(2,1)-v(1,1)]/detBK;

    % Curl of first-order Nedelec basis 
    curl_ref = 2/abs(detBK);

    for i=1:3
        for j=1:3
            ii = elems2edges(k,i);
            jj = elems2edges(k,j);

            % curl-curl term
            K(ii,jj) = K(ii,jj) + ...
                edgeSigns(k,i)*edgeSigns(k,j)* ...
                curl_ref*curl_ref*area;
        end
    end

    % Mass matrices (quadrature)
    for q=1:3
        xi = quad_pts(q,1);
        eta = quad_pts(q,2);
        lambda = [1-xi-eta; xi; eta];

        % Nedelec basis functions
        N = zeros(2,3);
        N(:,1) = lambda(2)*grad_lambda(:,3) - lambda(3)*grad_lambda(:,2);
        N(:,2) = lambda(3)*grad_lambda(:,1) - lambda(1)*grad_lambda(:,3);
        N(:,3) = lambda(1)*grad_lambda(:,2) - lambda(2)*grad_lambda(:,1);

        for i=1:3
            for j=1:3
                ii = elems2edges(k,i);
                jj = elems2edges(k,j);

                val = (N(:,i)'*N(:,j)) * abs(detBK) * quad_w(q);

                M(ii,jj) = M(ii,jj) + ...
                    edgeSigns(k,i)*edgeSigns(k,j)*val;

                M_eps(ii,jj) = M_eps(ii,jj) + ...
                    edgeSigns(k,i)*edgeSigns(k,j)*eps_k*val;
            end
        end
    end
end

%% PEC Boundary Condition
mid = (nodes(edges(:,1),:) + nodes(edges(:,2),:))/2;
r_mid = sqrt(sum(mid.^2,2));
isBnd = abs(r_mid - R) < R*1e-3;
free = find(~isBnd);

%% EIGENVALUE SOLVER
A = K(free,free) - k0^2*M_eps(free,free);
B = M(free,free);

sigma = (k0*(n_core-0.001))^2;
[vecs,vals] = eigs(A,B,8,sigma);

beta2 = real(diag(vals));
beta = sqrt(abs(beta2));

valid = find(beta>k0*n_clad & beta<k0*n_core);
neff = beta(valid)/k0;

%disp('Effective indices:')
%disp(sort(neff,'descend'))

%% PLOT

if isempty(valid)
    return
end

[~, order] = sort(neff,'descend');
mode_index = valid(order(1));

modeE = zeros(numEdges,1);
modeE(free) = vecs(:,mode_index);

% Normalize eigenvector field
modeE = modeE / max(abs(modeE));

E_mag = zeros(numElems,1);

for k=1:numElems

    vid = tri(k,:);
    v = nodes(vid,:);
    detBK = det([v(2,:)-v(1,:); v(3,:)-v(1,:)]');

    grad_lambda = zeros(2,3);
    grad_lambda(:,1) = [v(2,2)-v(3,2); v(3,1)-v(2,1)]/detBK;
    grad_lambda(:,2) = [v(3,2)-v(1,2); v(1,1)-v(3,1)]/detBK;
    grad_lambda(:,3) = [v(1,2)-v(2,2); v(2,1)-v(1,1)]/detBK;

    lambda = [1/3 1/3 1/3];

    N = zeros(2,3);
    N(:,1) = lambda(2)*grad_lambda(:,3) - lambda(3)*grad_lambda(:,2);
    N(:,2) = lambda(3)*grad_lambda(:,1) - lambda(1)*grad_lambda(:,3);
    N(:,3) = lambda(1)*grad_lambda(:,2) - lambda(2)*grad_lambda(:,1);

    Et = [0;0];

    for e=1:3
        eid = elems2edges(k,e);
        Et = Et + modeE(eid)*edgeSigns(k,e)*N(:,e);
    end

    E_mag(k) = norm(Et);
end

%figure('Color','w');
%patch('Faces',tri,'Vertices',nodes,...
      %'CData',E_mag,...
      %'FaceColor','flat',...
      %'EdgeColor','none');

%hold on
%theta = linspace(0,2*pi,300);
%plot(a*cos(theta),a*sin(theta),'w--','LineWidth',1.5)

%colormap(jet)
%colorbar
%axis equal tight

%title(['Fundamental Mode (n_{eff} = ', num2str(neff(order(1)),6), ')'])
%xlabel('x (m)')
%ylabel('y (m)')

%% POST-PROCESSING: Complex neff + Radial field profile

fprintf('\nEffective indices (complex form):\n');

for idx = 1:length(valid)
    fprintf('  neff(%d) = %.6f %+.6e i\n', ...
        idx, real(neff(idx)), imag(neff(idx)));
end

% Select fundamental mode 
[~, fundIdx] = max(real(neff));
modeNum = valid(fundIdx);

beta_mode = beta(modeNum);
neff_mode = beta_mode / k0;

fprintf('\nFundamental mode:\n');
fprintf('  beta = %.6e (1/m)\n', beta_mode);
fprintf('  neff = %.6f\n', neff_mode);

% Extract eigenvector (FULL complex)
Evec = complex(zeros(numEdges,1));
Evec(free) = vecs(:,modeNum);

% Normalize eigenvector
Evec = Evec / max(abs(Evec));


r_max = R;
numSamples = 250;

r_samples = linspace(0,r_max,numSamples);
E_radial = zeros(size(r_samples));

for i = 1:numSamples

    x = r_samples(i);
    y = 0;

    found = false;

    for k = 1:numElems

        verts = nodes(tri(k,:),:);

        if inpolygon(x,y,verts(:,1),verts(:,2))

            v = verts;

            detBK = det([v(2,:)-v(1,:); v(3,:)-v(1,:)]');

            grad_lambda = zeros(2,3);
            grad_lambda(:,1) = [v(2,2)-v(3,2); v(3,1)-v(2,1)]/detBK;
            grad_lambda(:,2) = [v(3,2)-v(1,2); v(1,1)-v(3,1)]/detBK;
            grad_lambda(:,3) = [v(1,2)-v(2,2); v(2,1)-v(1,1)]/detBK;

            % Barycentric coordinates
            A = [v(2,:)-v(1,:); v(3,:)-v(1,:)]';
            b = [x-v(1,1); y-v(1,2)];
            xi_eta = A\b;

            xi = xi_eta(1);
            eta = xi_eta(2);

            lambda = [1-xi-eta; xi; eta];

            % Nedelec basis
            N = zeros(2,3);
            N(:,1) = lambda(2)*grad_lambda(:,3) - lambda(3)*grad_lambda(:,2);
            N(:,2) = lambda(3)*grad_lambda(:,1) - lambda(1)*grad_lambda(:,3);
            N(:,3) = lambda(1)*grad_lambda(:,2) - lambda(2)*grad_lambda(:,1);

            Et = [0;0];

            for e = 1:3
                eid = elems2edges(k,e);
                Et = Et + Evec(eid)*edgeSigns(k,e)*N(:,e);
            end

            E_radial(i) = norm(Et);
            found = true;
            break
        end
    end

    if ~found
        E_radial(i) = NaN;
    end
end







Evec = Evec / sqrt(real(Evec' * M * Evec));
% Compute element centers
centers = zeros(numElems,2);
for k = 1:numElems
    centers(k,:) = mean(nodes(tri(k,:),:));
end

r_elem = sqrt(sum(centers.^2,2));

% Sort by radius
[r_sorted, idx] = sort(r_elem);
E_sorted = E_mag(idx);

%figure('Color','w');
%plot(r_sorted*1e6, E_sorted,'b','LineWidth',1.6)
%grid on
%hold on
%yl = ylim;
%plot([a a]*1e6,yl,'k--','LineWidth',1.2)

%xlabel('Radius (μm)')
%ylabel('|E|')
%title(['Radial profile (n_{eff} = ', num2str(real(neff_mode),6), ')'])
%legend('|E|','Core boundary')






